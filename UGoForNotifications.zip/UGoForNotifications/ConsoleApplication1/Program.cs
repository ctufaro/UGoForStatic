﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        public static List<int> sharedArray = new List<int>();
        
        static void Main(string[] args)
        {
            var tasks = new Task[2];
            tasks[0] = Task.Factory.StartNew(() => { GetFriends(); }, TaskCreationOptions.LongRunning);
            tasks[1] = Task.Factory.StartNew(() => { GetNotifications(); }, TaskCreationOptions.LongRunning);
            Task.WaitAll(tasks);
        }

        private static void GetFriends()
        {
            while (true)
            {
                Thread.Sleep(1000);
                Console.WriteLine("Adding");
                sharedArray.Add(1);
            }
        }

        private static void GetNotifications()
        {
            while (true)
            {
                Thread.Sleep(1000);
                Console.WriteLine(sharedArray.Count());
            }
        }

    }
}
