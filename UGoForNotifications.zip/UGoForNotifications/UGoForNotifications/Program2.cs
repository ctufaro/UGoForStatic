﻿using PushSharp;
using PushSharp.Apple;
using PushSharp.Core;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace UGoForNotifications
{
    class Program2
    {
        private static void RunMe()
        {
            //try
            //{
            //    Console.WriteLine("Running Notifications: " + DateTime.Now);
            //    string connection = "Server=tcp:vnc3ihd7kg.database.windows.net,1433;Database=UGoForDB;User ID=RadsurgeDB@vnc3ihd7kg;Password=zenC7ith;Connection Timeout=30;";
            //    List<Notifications> retNotif;
            //    Dictionary<int, List<string>> retFriends;
            //    UGoForNotifications.GetUGoForNotificaions(connection, out retNotif, out retFriends);
            //    UGoForNotifications.SendUGoForNotifications(connection, retNotif, retFriends);
            //    GC.Collect();
            //}
            //catch (Exception e) 
            //{
            //    System.IO.File.WriteAllText(@"C:\temp\ErrorLog-" + Guid.NewGuid().ToString()+".txt", e.ToString());
            //}
        }

        public static void Main2()
        {
            ////// Create a Timer object that knows to call our TimerCallback
            ////// method once every 2000 milliseconds.
            //Timer t = new Timer(TimerCallback, null, 0, 10000);
            ////// Wait for the user to hit <Enter>
            ////RunMe();
            //Console.ReadLine();

            //PushNotifcations.SendTestNotification("test", "2fcfef1bb9288a90f969b04cd33842c3bbe75c2760dba5bc17f82e570cb464f1");
            Console.ReadLine();
        }

        private static void TimerCallback(Object o)
        {
            RunMe();
        }

    }

    public class UGoForNotifications
    {
        public static void GetUGoForNotificaions(string _conn, out List<Notifications> retNotif, out Dictionary<int, List<string>> retFriends)
        {
            SqlConnection connection = new SqlConnection(_conn);

            retNotif = new List<Notifications>();
            retFriends = new Dictionary<int, List<string>>();

            //Lets make everyone friends with one another, this will change after we implement following
            SQLHelp.ExecuteSQL(_conn, SQLHelp.GetAllFriendsSQL());

            using (connection)
            {
                SqlCommand command = new SqlCommand("exec SelectNotificationsAndFriends", connection);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        retNotif.Add(new Notifications
                        {
                            Id = reader.GetInt32(0),
                            UserId = reader.GetInt32(1),
                            UserName = reader.GetString(10),
                            Message = reader.GetString(2),
                            Sound = reader.GetString(3),
                            MessageType = reader.GetInt32(7),
                            MessagePost = reader.GetInt32(8),
                            MessagePoster = reader.GetString(9)
                        });
                    }
                }

                reader.NextResult();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int userId = reader.GetInt32(0);
                        string deviceId = reader.GetString(1);
                        if (retFriends.ContainsKey(userId))
                        {
                            List<string> deviceIds = retFriends[userId];
                            deviceIds.Add(deviceId);
                        }
                        else
                        {
                            List<string> deviceIds = new List<string>();
                            deviceIds.Add(deviceId);
                            retFriends.Add(userId, deviceIds);
                        }
                    }
                }

                reader.Close();
            }

        }

        public static void SendUGoForNotifications(string _conn, List<Notifications> retNotif, Dictionary<int, List<string>> retFriends)
        {
            List<Notifications> finalNotification = new List<Notifications>();
            List<string> friendDevices = new List<string>();
            List<string> sqlUpdates = new List<string>();

            foreach (var notif in retNotif)
            {
                //check if key exists
                if (retFriends.ContainsKey(notif.UserId))
                {
                    friendDevices = retFriends[notif.UserId];
                }

                //comment
                if (notif.MessageType == 1)
                {
                    if (string.IsNullOrEmpty(notif.MessagePoster)) { continue; }
                    notif.Message = notif.UserName + " commented on your post";
                    finalNotification.Add(notif);
                    //Console.WriteLine(notif.UserName + " commented on your post (sent to "+ notif.MessagePoster+")");
                }
                //share yum
                else if (notif.MessageType == 2)
                {
                    string content = notif.Message;

                    foreach (var fd in friendDevices)
                    {
                        if (string.IsNullOrEmpty(fd)) { continue; }

                        Notifications newNotif = new Notifications();
                        newNotif.MessagePoster = fd;
                        newNotif.Message = notif.UserName + " shared a yum - " + content;
                        newNotif.Sound = notif.Sound;
                        finalNotification.Add(newNotif);
                        //Console.WriteLine(notif.UserName + " shared a yum:" + notif.Message + " (sent to " + x + ")");
                    }
                }
                //rave a crave
                else if (notif.MessageType == 3)
                {

                }

                //update here
                sqlUpdates.Add("UPDATE Notifications SET MessageSent = 1, MessageSentOn = GETDATE() WHERE ID = " + notif.Id);
            }


            using (SqlConnection connection = new SqlConnection(_conn))
            {
                foreach (string sql in sqlUpdates)
                {
                    SqlCommand command = new SqlCommand(sql, connection);
                    if (connection.State != System.Data.ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    command.ExecuteNonQuery();
                }
            }


            PushNotifcations.SendNotification(finalNotification);
        }
    }

    #region Helper Classes
    public class PushNotifcations
    {
        static void Send()
        {
            //Create our push services broker
            var push = new PushBroker();

            //Wire up the events for all the services that the broker registers
            push.OnNotificationSent += NotificationSent;
            push.OnChannelException += ChannelException;
            push.OnServiceException += ServiceException;
            push.OnNotificationFailed += NotificationFailed;
            push.OnDeviceSubscriptionExpired += DeviceSubscriptionExpired;
            push.OnDeviceSubscriptionChanged += DeviceSubscriptionChanged;
            push.OnChannelCreated += ChannelCreated;
            push.OnChannelDestroyed += ChannelDestroyed;


            //------------------------------------------------
            //IMPORTANT NOTE about Push Service Registrations
            //------------------------------------------------
            //Some of the methods in this sample such as 'RegisterAppleServices' depend on you referencing the correct
            //assemblies, and having the correct 'using PushSharp;' in your file since they are extension methods!!!

            // If you don't want to use the extension method helpers you can register a service like this:
            //push.RegisterService<WindowsPhoneToastNotification>(new WindowsPhonePushService());

            //If you register your services like this, you must register the service for each type of notification
            //you want it to handle.  In the case of WindowsPhone, there are several notification types!



            //-------------------------
            // APPLE NOTIFICATIONS
            //-------------------------
            //Configure and start Apple APNS
            // IMPORTANT: Make sure you use the right Push certificate.  Apple allows you to generate one for connecting to Sandbox,
            //   and one for connecting to Production.  You must use the right one, to match the provisioning profile you build your
            //   app with!

            //var appleCert = File.ReadAllBytes(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "../../../Resources/PushSharp.Apns.Sandbox.p12"));

            var appleCert = File.ReadAllBytes(@"C:\Users\Chris\Downloads\sandbox.p12");

            //IMPORTANT: If you are using a Development provisioning Profile, you must use the Sandbox push notification server 
            //  (so you would leave the first arg in the ctor of ApplePushChannelSettings as 'false')
            //  If you are using an AdHoc or AppStore provisioning profile, you must use the Production push notification server
            //  (so you would change the first arg in the ctor of ApplePushChannelSettings to 'true')
            push.RegisterAppleService(new ApplePushChannelSettings(false, appleCert, "zenC7ith")); //Extension method
            //Fluent construction of an iOS notification
            //IMPORTANT: For iOS you MUST MUST MUST use your own DeviceToken here that gets generated within your iOS app itself when the Application Delegate
            //  for registered for remote notifications is called, and the device token is passed back to you

            //Get Notifications From Database - Sloppy Shit
            string _connection = "Server=tcp:vnc3ihd7kg.database.windows.net,1433;Database=UGoForDB;User ID=RadsurgeDB@vnc3ihd7kg;Password=zenC7ith;Connection Timeout=30;";
            List<int> sendNotifIds = new List<int>();
            bool noRows = false;
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                SqlCommand command = new SqlCommand(
                  "SELECT n.*,u.DeviceId FROM Notifications n INNER JOIN Users u on n.UserId = U.Id WHERE MessageSent is NULL",
                  connection);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int notificationID = reader.GetInt32(0);
                        sendNotifIds.Add(notificationID);
                        push.QueueNotification(new AppleNotification()
                                        .ForDeviceToken(reader.GetString(7))
                                        .WithAlert(reader.GetString(3))
                                        .WithBadge(1)
                                        .WithSound(reader.GetString(2)));
                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                    noRows = true;
                }
                reader.Close();
            }

            if (noRows)
                return;

            string ids = "(" + string.Join(",", sendNotifIds) + ")";

            string sqlUpdate = "UPDATE Notifications SET MessageSent = 1, MessageSentOn = GETDATE() WHERE ID in " + ids;

            using (SqlConnection connection = new SqlConnection(_connection))
            {
                SqlCommand command = new SqlCommand(sqlUpdate, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }


            //push.QueueNotification(new AppleNotification()
            //                .ForDeviceToken("9b8110e338b572ea62883c198330aa056a5a6c4177beda29a2446aa5939f6428")
            //                .WithAlert("Chris is Craving Sex From His Hot Wife")
            //                .WithBadge(1)
            //                .WithSound("sound.caf"));

            //push.QueueNotification(new AppleNotification()
            //                .ForDeviceToken("3677a2ba88ae1e993e73ed42938e7cae601b452e93485d216ed06fde1c102d84")
            //                .WithAlert("Chris is Craving Sex From His Hot Wife")
            //                .WithBadge(1)
            //                .WithSound("sound.caf"));     

            ////---------------------------
            //// ANDROID GCM NOTIFICATIONS
            ////---------------------------
            ////Configure and start Android GCM
            ////IMPORTANT: The API KEY comes from your Google APIs Console App, under the API Access section, 
            ////  by choosing 'Create new Server key...'
            ////  You must ensure the 'Google Cloud Messaging for Android' service is enabled in your APIs Console
            //push.RegisterGcmService(new GcmPushChannelSettings("YOUR Google API's Console API Access  API KEY for Server Apps HERE"));
            ////Fluent construction of an Android GCM Notification
            ////IMPORTANT: For Android you MUST use your own RegistrationId here that gets generated within your Android app itself!
            //push.QueueNotification(new GcmNotification().ForDeviceRegistrationId("DEVICE REGISTRATION ID HERE")
            //                      .WithJson("{\"alert\":\"Hello World!\",\"badge\":7,\"sound\":\"sound.caf\"}"));


            ////-----------------------------
            //// WINDOWS PHONE NOTIFICATIONS
            ////-----------------------------
            ////Configure and start Windows Phone Notifications
            //push.RegisterWindowsPhoneService();
            ////Fluent construction of a Windows Phone Toast notification
            ////IMPORTANT: For Windows Phone you MUST use your own Endpoint Uri here that gets generated within your Windows Phone app itself!
            //push.QueueNotification(new WindowsPhoneToastNotification()
            //    .ForEndpointUri(new Uri("DEVICE REGISTRATION CHANNEL URI HERE"))
            //    .ForOSVersion(WindowsPhoneDeviceOSVersion.MangoSevenPointFive)
            //    .WithBatchingInterval(BatchingInterval.Immediate)
            //    .WithNavigatePath("/MainPage.xaml")
            //    .WithText1("PushSharp")
            //    .WithText2("This is a Toast"));


            ////-------------------------
            //// WINDOWS NOTIFICATIONS
            ////-------------------------
            ////Configure and start Windows Notifications
            //push.RegisterWindowsService(new WindowsPushChannelSettings("WINDOWS APP PACKAGE NAME HERE",
            //    "WINDOWS APP PACKAGE SECURITY IDENTIFIER HERE", "CLIENT SECRET HERE"));
            ////Fluent construction of a Windows Toast Notification
            //push.QueueNotification(new WindowsToastNotification()
            //    .AsToastText01("This is a test")
            //    .ForChannelUri("DEVICE CHANNEL URI HERE"));



            Console.WriteLine("Waiting for Queue to Finish...");

            //Stop and wait for the queues to drains
            push.StopAllServices();

            Console.WriteLine("Queue Finished, press return to exit...");
            //Console.ReadLine();			
        }

        public static void SendNotification(List<Notifications> notifications)
        {
            //Create our push services broker
            var push = new PushBroker();

            //Wire up the events for all the services that the broker registers
            push.OnNotificationSent += NotificationSent;
            push.OnChannelException += ChannelException;
            push.OnServiceException += ServiceException;
            push.OnNotificationFailed += NotificationFailed;
            push.OnDeviceSubscriptionExpired += DeviceSubscriptionExpired;
            push.OnDeviceSubscriptionChanged += DeviceSubscriptionChanged;
            push.OnChannelCreated += ChannelCreated;
            push.OnChannelDestroyed += ChannelDestroyed;

            var appleCert = File.ReadAllBytes(@"C:\Users\Chris\Downloads\sandbox.p12");

            push.RegisterAppleService(new ApplePushChannelSettings(false, appleCert, "zenC7ith")); //Extension method

            foreach (var notif in notifications)
            {
                push.QueueNotification(new AppleNotification()
                                            .ForDeviceToken(notif.MessagePoster)
                                            .WithAlert(notif.Message)
                                            .WithBadge(1)
                                            .WithSound(notif.Sound)
                                            .WithCustomItem("id", notif.MessagePost)
                                            .WithCustomItem("type", notif.MessageType)
                                            );
            }

            Console.WriteLine("Waiting for Queue to Finish...");

            push.StopAllServices();

            Console.WriteLine("Queue Finished, press return to exit...");
        }

        public static void SendTestNotification(string message, string deviceId)
        {
            Notifications single = new Notifications();
            single.Message = message;
            single.Id = 1;
            single.MessagePoster = deviceId;
            single.MessagePost = 1;
            single.MessageType = 1;
            single.Sound = "sound.caf";
            List<Notifications> n = new List<Notifications>();
            n.Add(single);
            PushNotifcations.SendNotification(n);
        }

        static void DeviceSubscriptionChanged(object sender, string oldSubscriptionId, string newSubscriptionId, INotification notification)
        {
            //Currently this event will only ever happen for Android GCM
            Console.WriteLine("Device Registration Changed:  Old-> " + oldSubscriptionId + "  New-> " + newSubscriptionId + " -> " + notification);
        }

        static void NotificationSent(object sender, INotification notification)
        {
            Console.WriteLine("Sent: " + sender + " -> " + notification);
        }

        static void NotificationFailed(object sender, INotification notification, Exception notificationFailureException)
        {
            Console.WriteLine("Failure: " + sender + " -> " + notificationFailureException.Message + " -> " + notification);
        }

        static void ChannelException(object sender, IPushChannel channel, Exception exception)
        {
            Console.WriteLine("Channel Exception: " + sender + " -> " + exception);
        }

        static void ServiceException(object sender, Exception exception)
        {
            Console.WriteLine("Service Exception: " + sender + " -> " + exception);
        }

        static void DeviceSubscriptionExpired(object sender, string expiredDeviceSubscriptionId, DateTime timestamp, INotification notification)
        {
            Console.WriteLine("Device Subscription Expired: " + sender + " -> " + expiredDeviceSubscriptionId);
        }

        static void ChannelDestroyed(object sender)
        {
            Console.WriteLine("Channel Destroyed for: " + sender);
        }

        static void ChannelCreated(object sender, IPushChannel pushChannel)
        {
            Console.WriteLine("Channel Created for: " + sender);
        }
    }

    public class Notifications
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Message { get; set; }
        public string MessagePoster { get; set; }
        public string Sound { get; set; }
        public string CustomJSON { get; set; }
        public int MessageType { get; set; }
        public int MessagePost { get; set; }
    }

    public class SQLHelp
    {
        public static void ExecuteSQL(string _conn, string sql)
        {
            using (SqlConnection connection = new SqlConnection(_conn))
            {
                SqlCommand command = new SqlCommand(sql, connection);
                if (connection.State != System.Data.ConnectionState.Open)
                {
                    connection.Open();
                }
                command.ExecuteNonQuery();
            }
        }

        public static string GetAllFriendsSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from friends ");
            sb.Append("insert into friends (userid,friendid) ");
            sb.Append("select distinct t1.Id,t2.Id ");
            sb.Append("from users t1 cross join users t2 ");
            sb.Append("where (t1.Id is not null and t2.Id is not null) and (t1.Id <> t2.Id)");
            return sb.ToString();
        }
    }
    #endregion
}
