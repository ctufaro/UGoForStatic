﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UGoForNotifications
{
    public class Enums
    {
        public enum Platforms
        {
            Apple,
            Android,
            Windows,
            Blackberry
        }

        public enum UGoForNotificationType
        {
            SharedAYum = 1,
            RaveACrave = 2,
            CommentACrave = 3,
            Yum = 4,
            Yuck = 5,
            FollowedBy = 6,            
            Prediction = 7
        }
    }
}
