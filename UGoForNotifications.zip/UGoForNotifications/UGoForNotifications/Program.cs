﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UGoForNotifications
{
    class Program
    {
        public static void Main(string[] args)
        {
            ApplePushNotification ap = new ApplePushNotification();
            Notification newNotification = new Notification();
            newNotification.DeviceId = "fbba9885d13f18732c32389e0a82cc7e987237b1c29207c4c74958ace89c5a31";
            newNotification.Sound = "sound.caf";
            newNotification.Message = "ugoforchris is now following you";
            newNotification.Badge = 3;
            ap.SendTest(newNotification);
            Console.ReadLine();
        }
    }
}
