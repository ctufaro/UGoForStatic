﻿using PushSharp;
using PushSharp.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UGoForNotifications
{
    public abstract class UGoForNotification
    {
        public PushBroker push;

        public UGoForNotification() 
        {
            push = new PushBroker();
        }

        public abstract void Send(List<Notification> notifications);
        public abstract void SendTest(Notification notification);
    }
}
