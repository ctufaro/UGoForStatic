﻿using PushSharp;
using PushSharp.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UGoForNotifications
{
    public class Notification
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int Badge { get; set; }
        public string DeviceId { get; set; }
        public string UserName { get; set; }
        public string Message { get; set; }
        public string MessagePoster { get; set; }
        public string Sound { get; set; }
        public string CustomJSON { get; set; }
        public int MessageType { get; set; }
        public int MessagePost { get; set; }
    }
}
