SELECT N.[Id]
      ,N.[UserId]
      ,U.Username
      ,[Message]
      ,[Sound]
      ,[CustomJSON]
      ,[MessageSent]
      ,[MessageSentOn]
      ,[MessageType]
      ,[MessagePost]
      ,CASE 
			WHEN MessageType = 1 THEN -1
			WHEN MessageType = 2 THEN -1
			WHEN MessageType = 6 THEN [MessagePost] 
			ELSE P.UserId 
			END [Recipient]	
			
  INTO #TMP
  FROM Notifications N
  LEFT JOIN Posts P on N.MessagePost = P.Id
  INNER JOIN Users U on U.Id = N.[UserId]
  ORDER BY MessageType 
  
  SELECT T.*,U.DeviceId [SendDevice] FROM #TMP T
  LEFT JOIN Users U ON U.Id = T.Recipient
  
  DROP TABLE #TMP
GO


