SELECT U.Id,A.Value[Friends]
  INTO #TMP    
  FROM [UGoForDB].[dbo].[Users] U
  LEFT JOIN (SELECT UserId, Value FROM Actions WHERE Action = 'follow') AS A ON U.ID = A.UserId
  ORDER BY Id
  
  SELECT * FROM #TMP
  
  DROP TABLE #TMP
  
GO


